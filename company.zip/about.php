<!DOCTYPE HTML>
<!--
	Greatness by FreeHTML5.co
	Twitter: http://twitter.com/fh5co
	URL: http://FreeHTML5.co
-->
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>آفاق السحب لتقنية المعلومات</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content=" تتصميم مواقع الكترونية و برامج محاسبية متخصصة" />
		<meta name="keywords" content="برامج ,محاسبة ,تصميم,ادارات,مواقع ,الكترونية,تصاميم مواقع الكترونية,تصاميم برامج محاسبية," />
		<meta name="author" content="آفاق السحب لتقنية المعلومات  " />

	

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="icon" sizes="180x180" href="images/lo5.png">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
				<div id="gtco-logo" ><a href="index.html" style="color: rgb(246, 253, 251); "></a></div>

				<div class="col-xs-2">
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li class="active"><a href="index.html">الرئيسية</a></li>
						<li  ><a href="about.html">من نحن</a></li>
						<li class="has-dropdown">
							<a href="services.html">خدماتنا</a>
						
						
						</li>
					
						<li><a href="contact.html">للتواصل</a></li>
					</ul>				</div>
			</div>
			
		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(images/6.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>آفاق السحب لتقنية المعلومات </h1>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2> آفاق السحب لتقنية المعلومات</h2>
					<p>لإن الرؤية التي قامت عليها والرسالة التي تهدف الى تحقيقها، والاستراتيجية التي تعمل بها في سبيل تحقيق الرؤية والرسالة تجعلنا الوجهه المفضة لكل البحاثين عن الحلول لأعمالهم...					</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-6">
					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الاستراتيجية</h3>
							<p>استراتيجيتنا تتلخص في ان نكون عامل جذب لكل الأيدي العاملة الماهرة، وتبني سياسات تدعم تدريب الخريجين الجدد للإستفادة من طاقاتهم، وللمساهمة في اعدادهم ليكونوا نواة للغد، هذا قطعا مع السعي لتطعيم فرق العمل لدينا بذوي الخبرات والمهارات .. ويساعد هذا التنوع والتباين في أعمار وخبرات فريق العمل على استخراج المهارات الابداعية، لأستخراج افضل</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الابداع و الابتكار</h3>
							<p>يعتمد فريق العمل علي الابداع و البحث عن الاختلاف و التميز في مشروعك في كل مراحل تنفيذه</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الاحترافية و الكفاءة</h3>
							<p>هي كلمات ستشاهدها و تستمتع بها عند العمل معنا</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
				

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الخبرة</h3>
							<p>نضع في مشروعك خبرة حصلنا عليها  من العمل في مجال التطوير التقني و البرمجي و التسويقي في مشاريع كثيرة في العديد من الدول العربية</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>خدمات ما بعد البيع</h3>
							<p>تستمر العلاقة معنا بعد تسليم المشروع و نفخر بعملاءنا لانهم مصدر نجاحنا .</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>السعر المناسب للخدمة<h3>
							<p>	نعتمد علي تحقيق اعلي قيمة استثمارية للعميل مقابل ما سيدفعه و خاصة تطوير المووقع  و تحويلة الى تطبيق </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="gtco-cover gtco-cover-sm" style="background-image:url(images/2.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>رضائكم هدفنا</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

			

	
				</div>
			</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-2 col-sm-4 col-xs-6 ">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="index.html">الرئيسية</a></li>
	
				
					</ul>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="#">المكتبة</a></li>
			
					</ul>
				</div>
				
				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="about.html">من نحن</a></li>
				
					</ul>
				</div>

				<div class="clearfix visible-sm-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">للتواصل</a></li>
		
					</ul>
				</div>

				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">موقعنا</a></li>
				
					</ul>
				</div>

				

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy;جميع الحقوق محفوظة 2020</small> 
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
		
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer></div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

