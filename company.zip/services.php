<!DOCTYPE HTML>
<!--
	Greatness by FreeHTML5.co
	Twitter: http://twitter.com/fh5co
	URL: http://FreeHTML5.co
-->
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>  آفاق السحب لتقنية المعلومات</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content=" تتصميم مواقع الأكترونية و برامج محاسبية متخصصة" />
		<meta name="keywords" content="برامج ,محاسبة ,تصميم,ادارات,مواقع ,الكترونية,تصاميم مواقع الكترونية,تصاميم برامج محاسبية," />
		<meta name="author" content="  آفاق السحب لتقنية المعلومات" />


  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link rel="icon" sizes="180x180" href="images/lo5.png">

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
				<div id="gtco-logo" ><a href="index.html" style="color: rgb(255, 255, 255); ">  </a></div>

				<div class="col-xs-2">
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li class="active"><a href="index.html">الرئيسية</a></li>
						<li  ><a href="about.html">من نحن</a></li>
						<li class="has-dropdown">
							<a href="services.html">خدماتنا</a>
						
						</li>
					
						<li><a href="contact.html">للتواصل</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(images/1231.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1> آفاق السحب لتقنية المعلومات</h1></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	
	<div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
					<div class="feature-center">
						<span class="icon">
							<i class="icon-eye"></i>
						</span>
						<h3>تصميم المواقع السياحية</h3>
						<p>نجاح أي شركة سياحية يعتمد في الأساس على التواصل مع الشركات فى الداخل والخارج، والتواصل مع الوكلاء حول العالم، ولعل الموقع الإلكترونى الانترنت متعدد اللغات هو أسهل وأقصر طرق التواصل</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
					<div class="feature-center">
						<span class="icon">
							<i class="icon-command"></i>
						</span>
						<h3>تصميم الموقع العقارية</h3>
						<p>لتسويق وهذا ما تطلب منا أن نقدم حلولا فنية متقدمة مع تقديم أفكار جديدة بشكل مستمر لنصل بموقعك إلى قمة المنافسة ولنسهل علىيك إدارة موقعك وتحديثه باستمرار مع ضمان تحقيق أعلى فائدة لزائر الموقع كى نسهل الوصول إلى مايبحث عنه بأفضل طريقة للبحث والعرض مع مراعاة القواعد الأساسية لمحركات البحث</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
					<div class="feature-center">
						<span class="icon">
							<i class="icon-power"></i>
						</span>
						<h3>تصميم مواقع الشركات
						</h3>
						<p>ما يميز خدماتنا في تصميم مواقع الشركات في هو فهم وادراك متطلبات العميل والتخطيط الجيد قبل الشروع في العمل كل المواقع تأتي بلوحة تحكم كاملة للتحكم في الموقع دون الحاجة للرجوع للشرك</p>
					</div>
				</div>

			
				</div>

			</div>


		</div>
	</div>


	<div class="gtco-cover gtco-cover-sm" style="background-image:url(images/dad.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>الوصول للقمة سهل لكن البقاء هو الاصعب وهذا ما نطمح اليه</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div id="gtco-features-2">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>لماذ تختار آفاق السحب لتقنية المعلومات</h2>
					<p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الثقة</h3>
							<p>	الثقة ليست وهبه بلى مكتسبه وهي مانسع جاهداً لكسبها بالتعامل معكم</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الدعم</h3>
							<p>سوف تكون في أيد أمينة . والدعم هي واحدة من أولوياتنا

							</p>
						</div>
					</div>

					<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
						<span class="icon">
							<i class="icon-check"></i>
						</span>
						<div class="feature-copy">
							<h3>الجودة
							</h3>
							<p>عندما يتعلق الأمر بتلبية احتياجات عملائنا وتوفير بيئة جيدة لهم فكُن على ثقة شديدة أنك فى يد أمينة ، وسنقوم بالتركيز معآ على أدق التفاصيل

							</p>
						</div>
					</div>

				</div>

				<div class="col-md-6">
					<div class="gtco-video gtco-bg" style="background-image: url(images/q.gif); ">
						<div class="overlay"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-2 col-sm-4 col-xs-6 ">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="index.html">الرئيسية</a></li>
	
				
					</ul>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="#">المكتبة</a></li>
			
					</ul>
				</div>
				
				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="about.html">من نحن</a></li>
				
					</ul>
				</div>

				<div class="clearfix visible-sm-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">للتواصل</a></li>
		
					</ul>
				</div>

				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">موقعنا</a></li>
				
					</ul>
				</div>

				

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<h1 class="block">&copy;جميع الحقوق محفوظة.</h1> 
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

