
<!DOCTYPE HTML>
<!--
	Greatness by FreeHTML5.co
	Twitter: http://twitter.com/fh5co
	URL: http://FreeHTML5.co
-->
<html>
	<head>

	
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title> آفاق السحب لتقنية المعلومات</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content=" آفاق السحب لتقنية المعلومات" />
		<meta name="keywords" content="برامج ,محاسبة ,تصميم,ادارات,مواقع ,الكترونية,تصاميم مواقع الكترونية,ةتصاميم برامج محاسبي," />
		<meta name="author" content="  آفاق السحب لتقنية المعلومات" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="icon" sizes="180x180" href="images/lo5.png">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
	<div class="gtco-loader">
		
	</div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
				<div id="gtco-logo" ><a href="index.html" style="color: rgb(255, 255, 255); ">  </a></div>

				<div class="col-xs-2">
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li class="active"><a href="index.html">الرئيسية</a></li>
						<li  ><a href="about.html">من نحن</a></li>
						<li class="has-dropdown">
							<a href="services.html">خدماتنا</a>
						
						</li>
					
						<li><a href="contact.html">للتواصل</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover" role="article" style="">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1 style="color: rgb(255, 255, 255);">  افاق السحب لتقنية المعلومات </h1>
							<p>
								 
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	
	<div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-eye"></i>
						</span>
						<h3>سهولة قرائة محتوى الموقع</h3>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-command"></i>
						</span>
						<h3>استجابة تامة</h3>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-power"></i>
						</span>
						<h3>افضل خيار لموقعك </h3>
					</div>
				</div>
			</div>
		</div>
	</div>

	

	
	<div id="gtco-counter" class="gtco-bg gtco-cover gtco-counter" style="background-image:url(images/7744.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="display-t">
					<div class="display-tc">
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-eye"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="2" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label"><h2> طلبات الاعمال </h2></span>

							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-anchor"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="2" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label"><h2>عدد عملانا</h2></span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-briefcase"></i>
								</span>
								<span class="counter js-counter" data-from="0" data-to="2" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label"><h2>الاعمال الانجزت</h2></span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-clock"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="10" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label"><h2>عدد الساعات لانجاز جميع الاعمال </h2></span>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="gtco-section">
	<div class="gtco-container">
		<div class="row animate-box">
			<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
				<h2>   كلمة فريق العمل  </h2>
				<h3  style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">فريق عمل نموذجي طموح يتسم بالشفافية والأمانة والإخلاص في العمل نعمل على تزويد عملانا بكل ماهو جديد ومفيد في مجال التقنية ويساعد على تطوير المنشآت من حيث البحث المستمر والتدقيق والمراجعة في مصداقية المعلومات ومشاركة التجارب وتبادل المعلومات مع الشركات العالمية والمحلية ومراكز الأبحاث . </h3>
			</div>
		</div>

		<div class="gtco-section">
			<div class="gtco-container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
						<h2>     الروية   </h2>
						<h3  style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;" >عمل جاهدين على المستقبل وتصخير الإمكانيات لي كي نكون في مصفوفة الشركات العالمية انطلاقاً من هذا البلد المعطاء . </h3>
					</div>
				</div>
		
				<div class="gtco-section">
					<div class="gtco-container">
						<div class="row animate-box">
							<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
								<h2>     الرسالة    </h2>
								<h3 style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;" >شاركونا آراؤكم ونقدكم البناء على أي من برامج التواصل الاجتماعي ، فهذا يسعدنا كما يساعدنا على الانطلاق بالشكل الصحيح نحو الأهداف المرجوه من وجود هذا الكيان . </h3>
							</div>
						</div>

	<div id="gtco-services">
		<div class="gtco-container">
			
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>ما هي خدماتنا </h2>
				<p>
					حلول الصيانة و الدعم الفني
<br>حلول الإستشارات التقنية
<br>حلول تصميم وتطوير مواقع الإنترنت والبوابات الإلكترونية .
				</p>
				</div>
			</div>

			<div class="row animate-box">
				
				<div class="gtco-tabs">
					<ul class="gtco-tab-nav">
						<li class="active"><a href="#" data-tab="1"><span class="icon visible-xs"><i class="icon-command"></i></span><span class="hidden-xs">تحويل الموقع الى تطبيق</span></a></li>
						<li><a href="#" data-tab="2"><span class="icon visible-xs"><i class="icon-bar-graph"></i></span><span class="hidden-xs">تصميم برامج محاسبة</span></a></li>
						<li><a href="#" data-tab="3"><span class="icon visible-xs"><i class="icon-bag"></i></span><span class="hidden-xs">تصميم المواقع الالكترونية</span></a></li>
						<li><a href="#" data-tab="4"><span class="icon visible-xs"><i class="icon-box"></i></span><span class="hidden-xs">تصميم الشعارات </span></a></li>
					</ul>

					<!-- Tabs -->
					<div class="gtco-tab-content-wrap">

						<div class="gtco-tab-content tab-content active" data-tab-content="1">
							<div class="col-md-6">
								<div class="gtco-video gtco-bg" style="background-image: url(images/android.gif); ">
									<div class="overlay"></div>
								</div>
							</div>
							<div class="col-md-6">
								<h2>تحويل موقعك الالكترونية الى تطبيق اندرويد</h2>
								<p></p>

								<p>تصميم تطبيق مربوط مع موقعك الالكترونية</p>

								<div class="row">
									<div class="col-md-6">
									
									</div>
									<div class="col-md-6">
									</div>
								</div>

							</div>
						</div>

						<div class="gtco-tab-content tab-content" data-tab-content="2">
							<div class="col-md-6 col-md-push-6">
								<div class="gtco-video gtco-bg" style="background-image: url(images/Accounting.gif); ">
									<div class="overlay"></div>
								</div>
							</div>
							<div class="col-md-6 col-md-pull-6">
								<h2>تصميم البرامج المحاسبية </h2>
								<p>برنامج يلائم مشروعك</p>

								<p>مصمم خصيصا لك</p>

								<div class="row">
									<div class="col-md-6">
									
									</div>
									<div class="col-md-6">
								
									</div>
								</div>

							</div>
						</div>

						<div class="gtco-tab-content tab-content" data-tab-content="3">
							<div class="col-md-6 col-md-push-6">
								<div class="gtco-video gtco-bg" style="background-image: url(images/res.gif); ">
									
									<div class="overlay"></div>
								</div>
							</div>
							<div class="col-md-6 col-md-pull-6">
								<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
									<span class="icon">
										<i class="icon-check"></i>
									</span>
									<div class="feature-copy">
										<h3>دعم فني متواصل و كامل </h3>
										<p>24/7</p>
									</div>
								</div>

								<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
									<span class="icon">
										<i class="icon-check"></i>
									</span>
									<div class="feature-copy">
										<h3>متوافق مع جميع الاجهزه</h3>
										<p>يتم استخدام افض ل اللغات البرمجية في تصميم موقعك الخاص</p>
									</div>
								</div>

								<div class="feature-left animate-box" data-animate-effect="fadeInLeft">
									<span class="icon">
										<i class="icon-check"></i>
									</span>
									<div class="feature-copy">
										<h3>يتم تصميم الموقع في 3ايام </h3>
										<p></p>
									</div>
								</div>
								
								
							</div>
						</div>

						<div class="gtco-tab-content tab-content" data-tab-content="4">
							<div class="col-md-6">
								<div class="icon icon-xlg">
									<i class="icon-box"></i>
								</div>
							</div>
							<div class="col-md-6">
								<h2>تصميم  الشعارات</h2>
								<p>تصميم مختلف الشعارات  لدعم  مشروعك الخاص </p>

								<p> يتم تصميم عددة شعارات  لجودة العمل و فن التصميم</p>

								<div class="row">
									<div class="col-md-6">
										<h2 class="uppercase">تصميم شعارات عن طريق الموكاب</h2>
										<p></p>
									</div>
									<div class="col-md-6">
										<h2 class="uppercase">تصميم شعار احترافي</h2>
										<p></p>
									</div>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</div>


	</div>

	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-2 col-sm-4 col-xs-6 ">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="index.html">الرئيسية</a></li>
	
				
					</ul>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="#">المكتبة</a></li>
			
					</ul>
				</div>
				
				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="about.html">من نحن</a></li>
				
					</ul>
				</div>

				<div class="clearfix visible-sm-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">للتواصل</a></li>
		
					</ul>
				</div>

				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">موقعنا</a></li>
				
					</ul>
				</div>

				

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy;جميع الحقوق محفوظة 2020</small> 
					</p>
					<p class="pull-right">
						
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

