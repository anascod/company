<!DOCTYPE HTML>
<!--
	Greatness by FreeHTML5.co
	Twitter: http://twitter.com/fh5co
	URL: http://FreeHTML5.co
-->
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>آفاق السحب لتقنية المعلومات</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content=" تصميم مواقع الكترونية, برامج محاسبية متخصصة" />
		<meta name="keywords" content="برامج ,محاسبة ,تصميم,ادارات,مواقع ,آفاق السحب لتقنية المعلومات,الكترونية,تصاميم مواقع الكترونية,تصاميم برامج محاسبية," />
		<meta name="author" content="  آفاق السحب لتقنية المعلومات" />

	

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<link rel="icon" sizes="180x180" href="images/lo5.png">

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			<div class="row">
				<div id="gtco-logo" ><a href="index.html" style="color: rgb(255, 255, 255); ">  </a></div>

				<div class="col-xs-2">
					
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li class="active"><a href="index.html">الرئيسية</a></li>
						<li  ><a href="about.html">من نحن</a></li>
						<li class="has-dropdown">
							<a href="services.html">خدماتنا</a>
					
						</li>
					
						<li><a href="contact.html">للتواصل</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(images/21.jpg);">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>آفاق السحب لتقنية المعلومات  </h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-6 animate-box">
					<h3>للتواصل</h3>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.6151724211686!2d46.79025741500238!3d24.84283068406223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDUwJzM0LjIiTiA0NsKwNDcnMzIuOCJF!5e0!3m2!1sen!2ssa!4v1600845213649!5m2!1sen!2ssa" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>				</div>
				<div class="col-md-5 col-md-push-1 animate-box">
					
					<div class="gtco-contact-info">
						<h3>مكتب الرياض</h3>
						<ul>
							<li class="address">الرياض, <br> تحديد </li>
							<li class="phone"><a href="tel://+966544757245">  </a></li>
							<li class="email"><a href="mailto:moOaf_m_j@hotmail.com">afaq-ss@hotmail.com</a></li>
						</ul>
					</div>

					<div class="gtco-contact-info">
						
					</div>

				</div>
			</div>
			
		</div>
	</div>
	
	


	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-pb-md">
				<div class="col-md-2 col-sm-4 col-xs-6 ">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="index.html">الرئيسية</a></li>
	
				
					</ul>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="#">المكتبة</a></li>
			
					</ul>
				</div>
				
				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="about.html">من نحن</a></li>
				
					</ul>
				</div>

				<div class="clearfix visible-sm-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">للتواصل</a></li>
		
					</ul>
				</div>

				<div class="clearfix visible-xs-block"></div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<ul class="gtco-footer-links">
						<li style="font-size: 20px;"><a href="contact.html">موقعنا</a></li>
				
					</ul>
				</div>

				

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy;جميع الحقوق محفوظة 2020</small> 
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer></div>

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

